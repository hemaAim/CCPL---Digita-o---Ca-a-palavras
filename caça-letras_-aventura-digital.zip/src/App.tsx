import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Monitor, Keyboard, Mouse, Cpu, Wifi, Globe, Code, Bot, Trophy, ArrowRight, RefreshCcw, User } from 'lucide-react';
import confetti from 'canvas-confetti';

type Phase = 1 | 2 | 3 | 4;

interface WordData {
  word: string;
  missingIndices: number[];
  hint: string;
  icon: any;
}

const PHASES_DATA: Record<Phase, WordData[]> = {
  1: [
    { word: 'CASA', missingIndices: [1], hint: 'Onde moramos', icon: Monitor },
    { word: 'PATO', missingIndices: [3], hint: 'Animal que faz quá-quá', icon: Mouse },
    { word: 'BOLA', missingIndices: [3], hint: 'Usada para jogar futebol', icon: Keyboard },
    { word: 'MESA', missingIndices: [0], hint: 'Onde colocamos o computador', icon: Cpu },
  ],
  2: [
    { word: 'MOUSE', missingIndices: [1, 3], hint: 'Usamos para clicar', icon: Mouse },
    { word: 'TELA', missingIndices: [0, 2], hint: 'Onde vemos as imagens', icon: Monitor },
    { word: 'TECLADO', missingIndices: [1, 4, 6], hint: 'Usamos para escrever', icon: Keyboard },
    { word: 'CHIP', missingIndices: [1, 3], hint: 'Cérebro do computador', icon: Cpu },
  ],
  3: [
    { word: 'CODIGO', missingIndices: [1, 3, 5], hint: 'Linguagem do programador', icon: Code },
    { word: 'REDE', missingIndices: [0, 2], hint: 'Conecta computadores', icon: Globe },
    { word: 'PIXEL', missingIndices: [1, 3], hint: 'Pontinho da imagem', icon: Monitor },
    { word: 'WIFI', missingIndices: [1, 3], hint: 'Internet sem fio', icon: Wifi },
  ],
  4: [
    { word: 'INTERNET', missingIndices: [1, 3, 5, 7], hint: 'Rede mundial', icon: Globe },
    { word: 'ROBO', missingIndices: [1, 3], hint: 'Máquina inteligente', icon: Bot },
    { word: 'LAPTOP', missingIndices: [1, 3, 5], hint: 'Computador portátil', icon: Monitor },
    { word: 'GAME', missingIndices: [1, 3], hint: 'Jogo eletrônico', icon: Trophy },
  ],
};

export default function App() {
  const [playerName, setPlayerName] = useState('');
  const [isStarted, setIsStarted] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<Phase>(1);
  const [answers, setAnswers] = useState<string[][]>([]);
  const [showResults, setShowResults] = useState(false);
  const [phaseScore, setPhaseScore] = useState(0);
  const [gameFinished, setGameFinished] = useState(false);

  useEffect(() => {
    // Initialize empty answers for current phase
    const currentWords = PHASES_DATA[currentPhase];
    setAnswers(currentWords.map(w => Array(w.missingIndices.length).fill('')));
  }, [currentPhase]);

  const handleStart = (e: FormEvent) => {
    e.preventDefault();
    if (playerName.trim()) {
      setIsStarted(true);
    }
  };

  const handleInputChange = (wordIdx: number, charIdx: number, value: string) => {
    const newAnswers = [...answers];
    newAnswers[wordIdx][charIdx] = value.toUpperCase().slice(0, 1);
    setAnswers(newAnswers);
  };

  const checkPhase = () => {
    const currentWords = PHASES_DATA[currentPhase];
    let correctCount = 0;
    let totalBlanks = 0;

    currentWords.forEach((wordData, wIdx) => {
      wordData.missingIndices.forEach((mIdx, charIdx) => {
        totalBlanks++;
        if (answers[wIdx][charIdx] === wordData.word[mIdx]) {
          correctCount++;
        }
      });
    });

    const scorePercent = (correctCount / totalBlanks) * 100;
    setPhaseScore(scorePercent);
    setShowResults(true);

    if (scorePercent >= 70) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  const nextPhase = () => {
    if (currentPhase < 4) {
      setCurrentPhase((prev) => (prev + 1) as Phase);
      setShowResults(false);
    } else {
      setGameFinished(true);
    }
  };

  const restartPhase = () => {
    const currentWords = PHASES_DATA[currentPhase];
    setAnswers(currentWords.map(w => Array(w.missingIndices.length).fill('')));
    setShowResults(false);
  };

  if (!isStarted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass p-8 w-full max-w-md text-center space-y-8 neon-border"
        >
          <div className="space-y-2">
            <h1 className="text-4xl font-display font-bold neon-text">Caça-Letras</h1>
            <p className="text-slate-400">Aventura Digital de Informática</p>
          </div>
          
          <form onSubmit={handleStart} className="space-y-6">
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Digite seu nome..."
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-cyan-400 transition-colors text-lg"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-4 rounded-xl transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 text-xl"
            >
              Começar Missão <ArrowRight className="w-6 h-6" />
            </button>
          </form>
          
          <div className="pt-4 border-t border-white/10 flex justify-center gap-4">
            <Monitor className="w-6 h-6 text-slate-500" />
            <Keyboard className="w-6 h-6 text-slate-500" />
            <Mouse className="w-6 h-6 text-slate-500" />
          </div>
        </motion.div>
      </div>
    );
  }

  if (gameFinished) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-slate-950">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="glass p-12 text-center space-y-6 max-w-lg neon-border"
        >
          <Trophy className="w-24 h-24 text-yellow-400 mx-auto drop-shadow-[0_0_15px_rgba(250,204,21,0.5)]" />
          <h2 className="text-4xl font-display font-bold">Parabéns, {playerName}!</h2>
          <p className="text-xl text-slate-300">Você completou todas as fases do Caça-Letras Digital e agora é um mestre da informática!</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-4 px-8 rounded-xl transition-all flex items-center gap-2 mx-auto text-xl"
          >
            Jogar Novamente <RefreshCcw className="w-6 h-6" />
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-slate-950 font-sans">
      <header className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center mb-12 gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center border border-cyan-500/50">
            <User className="text-cyan-400" />
          </div>
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-widest font-bold">Aluno(a)</p>
            <p className="text-xl font-bold text-white">{playerName}</p>
          </div>
        </div>

        <div className="flex gap-2">
          {[1, 2, 3, 4].map((p) => (
            <div
              key={p}
              className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold transition-all ${
                currentPhase === p
                  ? 'bg-cyan-500 text-slate-950 scale-110 shadow-[0_0_15px_rgba(34,211,238,0.5)]'
                  : currentPhase > p
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50'
                  : 'bg-slate-900 text-slate-600 border border-slate-800'
              }`}
            >
              {p}
            </div>
          ))}
        </div>
      </header>

      <main className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-display font-bold mb-2">Fase {currentPhase}: <span className="text-cyan-400">Desafio de Palavras</span></h2>
          <p className="text-slate-400">Complete as letras que faltam para avançar!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PHASES_DATA[currentPhase].map((wordData, wIdx) => (
            <motion.div
              key={wIdx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: wIdx * 0.1 }}
              className="glass p-6 space-y-4 hover:bg-white/15 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-900 rounded-lg">
                  <wordData.icon className="w-6 h-6 text-cyan-400" />
                </div>
                <span className="text-sm font-bold text-slate-400 uppercase tracking-wider">{wordData.hint}</span>
              </div>

              <div className="flex gap-2 justify-center py-4">
                {wordData.word.split('').map((char, cIdx) => {
                  const missingIdx = wordData.missingIndices.indexOf(cIdx);
                  const isMissing = missingIdx !== -1;

                  if (isMissing) {
                    return (
                      <input
                        key={cIdx}
                        type="text"
                        maxLength={1}
                        value={answers[wIdx]?.[missingIdx] || ''}
                        onChange={(e) => handleInputChange(wIdx, missingIdx, e.target.value)}
                        disabled={showResults}
                        className={`w-12 h-16 text-center text-3xl font-display font-bold rounded-xl border-2 transition-all focus:outline-none ${
                          showResults
                            ? answers[wIdx][missingIdx] === char
                              ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                              : 'bg-red-500/20 border-red-500 text-red-400'
                            : 'bg-slate-900 border-slate-700 focus:border-cyan-400 text-white'
                        }`}
                      />
                    );
                  }

                  return (
                    <div
                      key={cIdx}
                      className="w-12 h-16 flex items-center justify-center text-3xl font-display font-bold bg-slate-800/50 rounded-xl text-slate-400 border border-slate-700/50"
                    >
                      {char}
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          {!showResults ? (
            <button
              onClick={checkPhase}
              className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-4 px-12 rounded-2xl text-xl transition-all shadow-lg hover:shadow-cyan-500/20"
            >
              Verificar Respostas
            </button>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center space-y-6"
            >
              <div className="glass p-6 neon-border inline-block">
                <p className="text-2xl font-bold mb-2">
                  Pontuação: <span className={phaseScore >= 70 ? 'text-emerald-400' : 'text-red-400'}>{phaseScore.toFixed(0)}%</span>
                </p>
                <p className="text-slate-400">
                  {phaseScore >= 70 
                    ? 'Incrível! Você passou de fase!' 
                    : 'Quase lá! Você precisa de 70% para passar.'}
                </p>
              </div>

              <div className="flex gap-4 justify-center">
                {phaseScore < 70 ? (
                  <button
                    onClick={restartPhase}
                    className="bg-slate-800 hover:bg-slate-700 text-white font-bold py-4 px-8 rounded-xl flex items-center gap-2 transition-all"
                  >
                    Tentar Novamente <RefreshCcw className="w-5 h-5" />
                  </button>
                ) : (
                  <button
                    onClick={nextPhase}
                    className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-4 px-12 rounded-xl flex items-center gap-2 text-xl transition-all"
                  >
                    {currentPhase === 4 ? 'Finalizar Jogo' : 'Próxima Fase'} <ArrowRight className="w-6 h-6" />
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </div>
      </main>

      <footer className="max-w-4xl mx-auto mt-20 pt-8 border-t border-white/5 text-center text-slate-600 text-sm">
        <p>© 2024 Caça-Letras Digital • Curso de Informática</p>
      </footer>
    </div>
  );
}
